create_payload =
[
    {
        'nguid': '82b03fd9-1afb-463f-a3f8-2f30204d6561',
        'assets':
        [
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -2, 'y': 0.5, 'z': 2},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -1.5, 'y': 0.5, 'z': 2},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -8, 'y': 0.5, 'z': 2},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -8, 'y': 0.5, 'z': 2.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -9, 'y': 0.5, 'z': 2},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -9, 'y': 0.5, 'z': 2.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -10, 'y': 0.5, 'z': 2},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -10, 'y': 0.5, 'z': 2.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -16, 'y': 0.5, 'z': 2},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -15.5, 'y': 0.5, 'z': 2},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -2, 'y': 0.5, 'z': 3},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -1.5, 'y': 0.5, 'z': 3},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -8, 'y': 0.5, 'z': 3},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -8, 'y': 0.5, 'z': 3.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -9, 'y': 0.5, 'z': 3},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -9, 'y': 0.5, 'z': 3.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -10, 'y': 0.5, 'z': 3},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -10, 'y': 0.5, 'z': 3.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -16, 'y': 0.5, 'z': 3},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -15.5, 'y': 0.5, 'z': 3},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -2, 'y': 0.5, 'z': 4},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -1.5, 'y': 0.5, 'z': 4},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -8, 'y': 0.5, 'z': 4},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -8, 'y': 0.5, 'z': 4.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -9, 'y': 0.5, 'z': 4},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -9, 'y': 0.5, 'z': 4.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -10, 'y': 0.5, 'z': 4},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -10, 'y': 0.5, 'z': 4.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -16, 'y': 0.5, 'z': 4},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -15.5, 'y': 0.5, 'z': 4},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -2, 'y': 0.5, 'z': 5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -1.5, 'y': 0.5, 'z': 5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -8, 'y': 0.5, 'z': 5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -7.5, 'y': 0.5, 'z': 5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -10, 'y': 0.5, 'z': 5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -9.5, 'y': 0.5, 'z': 5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -16, 'y': 0.5, 'z': 5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -15.5, 'y': 0.5, 'z': 5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -2, 'y': 0.5, 'z': 6},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -1.5, 'y': 0.5, 'z': 6},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -8, 'y': 0.5, 'z': 6},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -7.5, 'y': 0.5, 'z': 6},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -11, 'y': 0.5, 'z': 6},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -10.5, 'y': 0.5, 'z': 6},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -16, 'y': 0.5, 'z': 6},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -15.5, 'y': 0.5, 'z': 6},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -2, 'y': 0.5, 'z': 7},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -2, 'y': 0.5, 'z': 7.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -3, 'y': 0.5, 'z': 7},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -3, 'y': 0.5, 'z': 7.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -4, 'y': 0.5, 'z': 7},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -4, 'y': 0.5, 'z': 7.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -6, 'y': 0.5, 'z': 7},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -6, 'y': 0.5, 'z': 7.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -7, 'y': 0.5, 'z': 7},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -7, 'y': 0.5, 'z': 7.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -11, 'y': 0.5, 'z': 7},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -11, 'y': 0.5, 'z': 7.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -12, 'y': 0.5, 'z': 7},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -12, 'y': 0.5, 'z': 7.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -14, 'y': 0.5, 'z': 7},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -14, 'y': 0.5, 'z': 7.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -15, 'y': 0.5, 'z': 7},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -15, 'y': 0.5, 'z': 7.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -16, 'y': 0.5, 'z': 7},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -16, 'y': 0.5, 'z': 7.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -7, 'y': 0.5, 'z': 8},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -6.5, 'y': 0.5, 'z': 8},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -11, 'y': 0.5, 'z': 8},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -10.5, 'y': 0.5, 'z': 8},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -6, 'y': 0.5, 'z': 11},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -5.5, 'y': 0.5, 'z': 11},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -12, 'y': 0.5, 'z': 11},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -11.5, 'y': 0.5, 'z': 11},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -6, 'y': 0.5, 'z': 12},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -5.5, 'y': 0.5, 'z': 12},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -12, 'y': 0.5, 'z': 12},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -11.5, 'y': 0.5, 'z': 12},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -2, 'y': 0.5, 'z': 14},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -2, 'y': 0.5, 'z': 14.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -3, 'y': 0.5, 'z': 14},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -3, 'y': 0.5, 'z': 14.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -4, 'y': 0.5, 'z': 14},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -4, 'y': 0.5, 'z': 14.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -5, 'y': 0.5, 'z': 14},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -5, 'y': 0.5, 'z': 14.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -6, 'y': 0.5, 'z': 14},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -6, 'y': 0.5, 'z': 14.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -7, 'y': 0.5, 'z': 14},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -7, 'y': 0.5, 'z': 14.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -8, 'y': 0.5, 'z': 14},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -8, 'y': 0.5, 'z': 14.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -10, 'y': 0.5, 'z': 14},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -10, 'y': 0.5, 'z': 14.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -11, 'y': 0.5, 'z': 14},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -11, 'y': 0.5, 'z': 14.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -12, 'y': 0.5, 'z': 14},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -12, 'y': 0.5, 'z': 14.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -13, 'y': 0.5, 'z': 14},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -13, 'y': 0.5, 'z': 14.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -14, 'y': 0.5, 'z': 14},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -14, 'y': 0.5, 'z': 14.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -15, 'y': 0.5, 'z': 14},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -15, 'y': 0.5, 'z': 14.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -16, 'y': 0.5, 'z': 14},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -16, 'y': 0.5, 'z': 14.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -2, 'y': 0.5, 'z': 15},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -2, 'y': 0.5, 'z': 15.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -3, 'y': 0.5, 'z': 15},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -3, 'y': 0.5, 'z': 15.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -4, 'y': 0.5, 'z': 15},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -4, 'y': 0.5, 'z': 15.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -5, 'y': 0.5, 'z': 15},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -5, 'y': 0.5, 'z': 15.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -6, 'y': 0.5, 'z': 15},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -6, 'y': 0.5, 'z': 15.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -12, 'y': 0.5, 'z': 15},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -12, 'y': 0.5, 'z': 15.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -13, 'y': 0.5, 'z': 15},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -13, 'y': 0.5, 'z': 15.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -14, 'y': 0.5, 'z': 15},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -14, 'y': 0.5, 'z': 15.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -15, 'y': 0.5, 'z': 15},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -15, 'y': 0.5, 'z': 15.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -16, 'y': 0.5, 'z': 15},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -16, 'y': 0.5, 'z': 15.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -2, 'y': 0.5, 'z': 16},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -2, 'y': 0.5, 'z': 16.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -3, 'y': 0.5, 'z': 16},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -3, 'y': 0.5, 'z': 16.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -4, 'y': 0.5, 'z': 16},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -4, 'y': 0.5, 'z': 16.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -5, 'y': 0.5, 'z': 16},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -5, 'y': 0.5, 'z': 16.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -6, 'y': 0.5, 'z': 16},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -6, 'y': 0.5, 'z': 16.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -12, 'y': 0.5, 'z': 16},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -12, 'y': 0.5, 'z': 16.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -13, 'y': 0.5, 'z': 16},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -13, 'y': 0.5, 'z': 16.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -14, 'y': 0.5, 'z': 16},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -14, 'y': 0.5, 'z': 16.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -15, 'y': 0.5, 'z': 16},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -15, 'y': 0.5, 'z': 16.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -16, 'y': 0.5, 'z': 16},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -16, 'y': 0.5, 'z': 16.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -2, 'y': 0.5, 'z': 17},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -2, 'y': 0.5, 'z': 17.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -3, 'y': 0.5, 'z': 17},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -3, 'y': 0.5, 'z': 17.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -4, 'y': 0.5, 'z': 17},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -4, 'y': 0.5, 'z': 17.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -5, 'y': 0.5, 'z': 17},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -5, 'y': 0.5, 'z': 17.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -6, 'y': 0.5, 'z': 17},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -6, 'y': 0.5, 'z': 17.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -12, 'y': 0.5, 'z': 17},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -12, 'y': 0.5, 'z': 17.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -13, 'y': 0.5, 'z': 17},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -13, 'y': 0.5, 'z': 17.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -14, 'y': 0.5, 'z': 17},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -14, 'y': 0.5, 'z': 17.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -15, 'y': 0.5, 'z': 17},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -15, 'y': 0.5, 'z': 17.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -16, 'y': 0.5, 'z': 17},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -16, 'y': 0.5, 'z': 17.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -2, 'y': 0.5, 'z': 18},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -2, 'y': 0.5, 'z': 18.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -3, 'y': 0.5, 'z': 18},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -3, 'y': 0.5, 'z': 18.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -4, 'y': 0.5, 'z': 18},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -4, 'y': 0.5, 'z': 18.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -5, 'y': 0.5, 'z': 18},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -5, 'y': 0.5, 'z': 18.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -6, 'y': 0.5, 'z': 18},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -6, 'y': 0.5, 'z': 18.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -12, 'y': 0.5, 'z': 18},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -12, 'y': 0.5, 'z': 18.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -13, 'y': 0.5, 'z': 18},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -13, 'y': 0.5, 'z': 18.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -14, 'y': 0.5, 'z': 18},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -14, 'y': 0.5, 'z': 18.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -15, 'y': 0.5, 'z': 18},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -15, 'y': 0.5, 'z': 18.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -16, 'y': 0.5, 'z': 18},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -16, 'y': 0.5, 'z': 18.5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            }
        ]
    },
    {
        'nguid': 'ff6b5a27-a041-4ba1-ad33-01d82c77bb34',
        'assets':
        [
            {
                'rotation': 12,
                'bounds':
                {
                    'center': {'x': -3, 'y': 0, 'z': 2},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -7, 'y': 0, 'z': 2},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 12,
                'bounds':
                {
                    'center': {'x': -11, 'y': 0, 'z': 2},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -15, 'y': 0, 'z': 2},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -8, 'y': 0, 'z': 9},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 8,
                'bounds':
                {
                    'center': {'x': -10, 'y': 0, 'z': 9},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 8,
                'bounds':
                {
                    'center': {'x': -2, 'y': 0, 'z': 13},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -16, 'y': 0, 'z': 13},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 8,
                'bounds':
                {
                    'center': {'x': -7, 'y': 0, 'z': 18},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -11, 'y': 0, 'z': 18},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            }
        ]
    },
    {
        'nguid': '910bdbf7-1cdf-4601-929a-9c89c5eaa8be',
        'assets':
        [
            {
                'rotation': 12,
                'bounds':
                {
                    'center': {'x': -4, 'y': 0, 'z': 3},
                    'extents': { 'x': 2, 'y': 1, 'z': 2}
                }
            },
            {
                'rotation': 12,
                'bounds':
                {
                    'center': {'x': -9, 'y': 0, 'z': 18},
                    'extents': { 'x': 2, 'y': 1, 'z': 2}
                }
            }
        ]
    },
    {
        'nguid': '05b8b832-e457-4ea7-88d5-25fa44037f39',
        'assets':
        [
            {
                'rotation': 12,
                'bounds':
                {
                    'center': {'x': -6, 'y': 0, 'z': 2},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 12,
                'bounds':
                {
                    'center': {'x': -14, 'y': 0, 'z': 2},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 8,
                'bounds':
                {
                    'center': {'x': -3, 'y': 0, 'z': 3},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -7, 'y': 0, 'z': 3},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 8,
                'bounds':
                {
                    'center': {'x': -11, 'y': 0, 'z': 3},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -15, 'y': 0, 'z': 3},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 8,
                'bounds':
                {
                    'center': {'x': -3, 'y': 0, 'z': 4},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -7, 'y': 0, 'z': 4},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 8,
                'bounds':
                {
                    'center': {'x': -11, 'y': 0, 'z': 4},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -15, 'y': 0, 'z': 4},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 8,
                'bounds':
                {
                    'center': {'x': -3, 'y': 0, 'z': 5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -7, 'y': 0, 'z': 5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 8,
                'bounds':
                {
                    'center': {'x': -11, 'y': 0, 'z': 5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -15, 'y': 0, 'z': 5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 8,
                'bounds':
                {
                    'center': {'x': -3, 'y': 0, 'z': 6},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -7, 'y': 0, 'z': 6},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -10, 'y': 0, 'z': 6},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -15, 'y': 0, 'z': 6},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 8,
                'bounds':
                {
                    'center': {'x': -8, 'y': 0, 'z': 7},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -10, 'y': 0, 'z': 7},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 8,
                'bounds':
                {
                    'center': {'x': -2, 'y': 0, 'z': 8},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -6, 'y': 0, 'z': 8},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 8,
                'bounds':
                {
                    'center': {'x': -8, 'y': 0, 'z': 8},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -10, 'y': 0, 'z': 8},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 8,
                'bounds':
                {
                    'center': {'x': -12, 'y': 0, 'z': 8},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -16, 'y': 0, 'z': 8},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 8,
                'bounds':
                {
                    'center': {'x': -2, 'y': 0, 'z': 9},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -6, 'y': 0, 'z': 9},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 12,
                'bounds':
                {
                    'center': {'x': -7, 'y': 0, 'z': 9},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 12,
                'bounds':
                {
                    'center': {'x': -11, 'y': 0, 'z': 9},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 8,
                'bounds':
                {
                    'center': {'x': -12, 'y': 0, 'z': 9},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -16, 'y': 0, 'z': 9},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 8,
                'bounds':
                {
                    'center': {'x': -2, 'y': 0, 'z': 10},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -16, 'y': 0, 'z': 10},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 8,
                'bounds':
                {
                    'center': {'x': -2, 'y': 0, 'z': 11},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -16, 'y': 0, 'z': 11},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 8,
                'bounds':
                {
                    'center': {'x': -2, 'y': 0, 'z': 12},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -16, 'y': 0, 'z': 12},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -3, 'y': 0, 'z': 13},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -4, 'y': 0, 'z': 13},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -5, 'y': 0, 'z': 13},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 8,
                'bounds':
                {
                    'center': {'x': -6, 'y': 0, 'z': 13},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -12, 'y': 0, 'z': 13},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -15, 'y': 0, 'z': 13},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 8,
                'bounds':
                {
                    'center': {'x': -7, 'y': 0, 'z': 15},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -11, 'y': 0, 'z': 15},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 8,
                'bounds':
                {
                    'center': {'x': -7, 'y': 0, 'z': 16},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -11, 'y': 0, 'z': 16},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 8,
                'bounds':
                {
                    'center': {'x': -7, 'y': 0, 'z': 17},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -11, 'y': 0, 'z': 17},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -8, 'y': 0, 'z': 18},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            }
        ]
    },
    {
        'nguid': 'f8fdaf2d-3b5b-47d8-8e1d-077994535798',
        'assets':
        [
            {
                'rotation': 12,
                'bounds':
                {
                    'center': {'x': -12, 'y': 0, 'z': 3},
                    'extents': { 'x': 2, 'y': 1, 'z': 2}
                }
            }
        ]
    },
    {
        'nguid': 'cf6063bb-5c6e-4107-b3e9-9c0c5ac75768',
        'assets':
        [
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -6, 'y': 0, 'z': 3},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -14, 'y': 0, 'z': 3},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -4, 'y': 0, 'z': 4},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -5, 'y': 0, 'z': 4},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -6, 'y': 0, 'z': 4},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -12, 'y': 0, 'z': 4},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -13, 'y': 0, 'z': 4},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -14, 'y': 0, 'z': 4},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -4, 'y': 0, 'z': 5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -5, 'y': 0, 'z': 5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -6, 'y': 0, 'z': 5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -9, 'y': 0, 'z': 5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -12, 'y': 0, 'z': 5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -13, 'y': 0, 'z': 5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -14, 'y': 0, 'z': 5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -4, 'y': 0, 'z': 6},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -5, 'y': 0, 'z': 6},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -6, 'y': 0, 'z': 6},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -9, 'y': 0, 'z': 6},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -12, 'y': 0, 'z': 6},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -13, 'y': 0, 'z': 6},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -14, 'y': 0, 'z': 6},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -5, 'y': 0, 'z': 7},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -9, 'y': 0, 'z': 7},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -13, 'y': 0, 'z': 7},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -3, 'y': 0, 'z': 8},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -4, 'y': 0, 'z': 8},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -5, 'y': 0, 'z': 8},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -9, 'y': 0, 'z': 8},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -13, 'y': 0, 'z': 8},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -14, 'y': 0, 'z': 8},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -15, 'y': 0, 'z': 8},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -3, 'y': 0, 'z': 9},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -4, 'y': 0, 'z': 9},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -5, 'y': 0, 'z': 9},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -9, 'y': 0, 'z': 9},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -13, 'y': 0, 'z': 9},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -14, 'y': 0, 'z': 9},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -15, 'y': 0, 'z': 9},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -3, 'y': 0, 'z': 10},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -4, 'y': 0, 'z': 10},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -5, 'y': 0, 'z': 10},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -6, 'y': 0, 'z': 10},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -7, 'y': 0, 'z': 10},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -8, 'y': 0, 'z': 10},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -9, 'y': 0, 'z': 10},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -10, 'y': 0, 'z': 10},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -11, 'y': 0, 'z': 10},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -12, 'y': 0, 'z': 10},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -13, 'y': 0, 'z': 10},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -14, 'y': 0, 'z': 10},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -15, 'y': 0, 'z': 10},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -3, 'y': 0, 'z': 11},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -4, 'y': 0, 'z': 11},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -5, 'y': 0, 'z': 11},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -7, 'y': 0, 'z': 11},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -8, 'y': 0, 'z': 11},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -9, 'y': 0, 'z': 11},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -10, 'y': 0, 'z': 11},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -11, 'y': 0, 'z': 11},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -13, 'y': 0, 'z': 11},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -14, 'y': 0, 'z': 11},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -15, 'y': 0, 'z': 11},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -3, 'y': 0, 'z': 12},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -4, 'y': 0, 'z': 12},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -5, 'y': 0, 'z': 12},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -7, 'y': 0, 'z': 12},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -8, 'y': 0, 'z': 12},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -9, 'y': 0, 'z': 12},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -10, 'y': 0, 'z': 12},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -11, 'y': 0, 'z': 12},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -15, 'y': 0, 'z': 12},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -7, 'y': 0, 'z': 13},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -8, 'y': 0, 'z': 13},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -9, 'y': 0, 'z': 13},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -10, 'y': 0, 'z': 13},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -11, 'y': 0, 'z': 13},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -9, 'y': 0, 'z': 14},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -8, 'y': 0, 'z': 15},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -9, 'y': 0, 'z': 15},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -10, 'y': 0, 'z': 15},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -8, 'y': 0, 'z': 16},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -9, 'y': 0, 'z': 16},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -10, 'y': 0, 'z': 16},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 0,
                'bounds':
                {
                    'center': {'x': -8, 'y': 0, 'z': 17},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            }
        ]
    },
    {
        'nguid': 'a9759b32-9ad0-4157-ba8f-7d7e73a1f00c',
        'assets':
        [
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -8.5, 'y': 0.5, 'z': 5},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 8,
                'bounds':
                {
                    'center': {'x': -5, 'y': 0.5, 'z': 7},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 8,
                'bounds':
                {
                    'center': {'x': -13, 'y': 0.5, 'z': 7},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 8,
                'bounds':
                {
                    'center': {'x': -9, 'y': 0.5, 'z': 9},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -5.5, 'y': 0.5, 'z': 10},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 4,
                'bounds':
                {
                    'center': {'x': -11.5, 'y': 0.5, 'z': 10},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            },
            {
                'rotation': 8,
                'bounds':
                {
                    'center': {'x': -9, 'y': 0.5, 'z': 14},
                    'extents': { 'x': 1, 'y': 1, 'z': 1}
                }
            }
        ]
    },
    {
        'nguid': 'd3ec0216-95e4-44cc-b076-74f39504166e',
        'assets':
        [
            {
                'rotation': 12,
                'bounds':
                {
                    'center': {'x': -13, 'y': 0, 'z': 13},
                    'extents': { 'x': 2, 'y': 1, 'z': 2}
                }
            }
        ]
    }
]
